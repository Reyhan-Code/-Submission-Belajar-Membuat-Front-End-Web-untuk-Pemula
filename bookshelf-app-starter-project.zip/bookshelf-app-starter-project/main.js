document.addEventListener("DOMContentLoaded", () => {
    const bookForm = document.getElementById("bookForm");
    const searchForm = document.getElementById("searchBook");
    const incompleteBookList = document.getElementById("incompleteBookList");
    const completeBookList = document.getElementById("completeBookList");
    const deleteModal = document.getElementById("deleteModal");
    const modalMessage = document.getElementById("modalMessage");
    const confirmDeleteButton = document.getElementById("confirmDeleteButton");
    const cancelDeleteButton = document.getElementById("cancelDeleteButton");

    let bookToDeleteId = null;

    const saveBooksToLocalStorage = () => {
        localStorage.setItem("books", JSON.stringify(books));
    };

    const loadBooksFromLocalStorage = () => {
        const storedBooks = localStorage.getItem("books");
        return storedBooks ? JSON.parse(storedBooks) : [];
    };

    let books = loadBooksFromLocalStorage();

    const renderBooks = () => {
        incompleteBookList.innerHTML = "";
        completeBookList.innerHTML = "";

        books.forEach((book) => {
            const bookItem = document.createElement("div");
            bookItem.dataset.bookid = book.id;
            bookItem.dataset.testid = "bookItem";

            const title = document.createElement("h3");
            title.dataset.testid = "bookItemTitle";
            title.textContent = book.title;

            const author = document.createElement("p");
            author.dataset.testid = "bookItemAuthor";
            author.textContent = `Penulis: ${book.author}`;

            const year = document.createElement("p");
            year.dataset.testid = "bookItemYear";
            year.textContent = `Tahun: ${book.year}`;

            const buttonContainer = document.createElement("div");

            const toggleButton = document.createElement("button");
            toggleButton.dataset.testid = "bookItemIsCompleteButton";
            toggleButton.textContent = book.isComplete
                ? "Belum selesai dibaca"
                : "Selesai dibaca";
            toggleButton.addEventListener("click", () => {
                book.isComplete = !book.isComplete;
                saveBooksToLocalStorage();
                renderBooks();
            });

            const deleteButton = document.createElement("button");
            deleteButton.dataset.testid = "bookItemDeleteButton";
            deleteButton.textContent = "Hapus Buku";
            deleteButton.addEventListener("click", () => {
                bookToDeleteId = book.id;
                modalMessage.textContent = `Apakah Anda yakin ingin menghapus buku "${book.title}"?`;
                deleteModal.style.display = "flex";
            });

            confirmDeleteButton.addEventListener("click", () => {
                books = books.filter((b) => b.id !== bookToDeleteId);
                saveBooksToLocalStorage();
                bookToDeleteId = null;
                renderBooks();
                deleteModal.style.display = "none";
            });

            cancelDeleteButton.addEventListener("click", () => {
                bookToDeleteId = null;
                deleteModal.style.display = "none";
            });

            const editButton = document.createElement("button");
            editButton.dataset.testid = "bookItemEditButton";
            editButton.textContent = "Edit Buku";
            editButton.addEventListener("click", () => {
                document.getElementById("bookFormTitle").value = book.title;
                document.getElementById("bookFormAuthor").value = book.author;
                document.getElementById("bookFormYear").value = book.year;
                document.getElementById("bookFormIsComplete").checked = book.isComplete;

                books = books.filter((b) => b.id !== book.id);
                saveBooksToLocalStorage();
                renderBooks();
            });

            buttonContainer.append(toggleButton, deleteButton, editButton);
            bookItem.append(title, author, year, buttonContainer);

            if (book.isComplete) {
                completeBookList.appendChild(bookItem);
            } else {
                incompleteBookList.appendChild(bookItem);
            }
        });
    };

    bookForm.addEventListener("submit", (event) => {
        event.preventDefault();

        const title = document.getElementById("bookFormTitle").value;
        const author = document.getElementById("bookFormAuthor").value;
        const year = Number(document.getElementById("bookFormYear").value);
        const isComplete = document.getElementById("bookFormIsComplete").checked;

        const newBook = {
            id: Date.now().toString(),
            title,
            author,
            year,
            isComplete,
        };

        books.push(newBook);
        saveBooksToLocalStorage();
        bookForm.reset();
        renderBooks();
    });


    document.getElementById("searchBook").addEventListener("submit", (event) => {
        event.preventDefault();

        const searchTitle = document.getElementById("searchBookTitle").value.toLowerCase();
        const filteredBooks = books.filter((book) =>
            book.title.toLowerCase().includes(searchTitle)
        );

        incompleteBookList.innerHTML = "";
        completeBookList.innerHTML = "";

        filteredBooks.forEach((book) => {
            const bookItem = document.createElement("div");
            bookItem.dataset.bookid = book.id;
            bookItem.dataset.testid = "bookItem";

            const title = document.createElement("h3");
            title.dataset.testid = "bookItemTitle";
            title.textContent = book.title;

            const author = document.createElement("p");
            author.dataset.testid = "bookItemAuthor";
            author.textContent = `Penulis: ${book.author}`;

            const year = document.createElement("p");
            year.dataset.testid = "bookItemYear";
            year.textContent = `Tahun: ${book.year}`;

            const buttonContainer = document.createElement("div");

            const toggleButton = document.createElement("button");
            toggleButton.dataset.testid = "bookItemIsCompleteButton";
            toggleButton.textContent = book.isComplete
                ? "Belum selesai dibaca"
                : "Selesai dibaca";
            toggleButton.addEventListener("click", () => {
                book.isComplete = !book.isComplete;
                saveBooksToLocalStorage();
                renderBooks();
            });

            const deleteButton = document.createElement("button");
            deleteButton.dataset.testid = "bookItemDeleteButton";
            deleteButton.textContent = "Hapus Buku";
            deleteButton.addEventListener("click", () => {
                bookToDeleteId = book.id;
                modalMessage.textContent = `Apakah Anda yakin ingin menghapus buku "${book.title}"?`;
                deleteModal.style.display = "flex";
            });

            const editButton = document.createElement("button");
            editButton.dataset.testid = "bookItemEditButton";
            editButton.textContent = "Edit Buku";
            editButton.addEventListener("click", () => {
                document.getElementById("bookFormTitle").value = book.title;
                document.getElementById("bookFormAuthor").value = book.author;
                document.getElementById("bookFormYear").value = String(book.year);
                document.getElementById("bookFormIsComplete").checked = book.isComplete;

                books = books.filter((b) => b.id !== book.id);
                saveBooksToLocalStorage();
                renderBooks();
            });

            buttonContainer.append(toggleButton, deleteButton, editButton);
            bookItem.append(title, author, year, buttonContainer);

            if (book.isComplete) {
                completeBookList.appendChild(bookItem);
            } else {
                incompleteBookList.appendChild(bookItem);
            }
        });
    });



    renderBooks();
});
